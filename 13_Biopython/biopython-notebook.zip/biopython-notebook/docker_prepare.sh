source activate python3
#conda install -c https://conda.binstar.org/bpeng simuPOP
conda install biopython
source deactivate
