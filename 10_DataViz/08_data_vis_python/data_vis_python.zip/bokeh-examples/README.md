The examples in this directory illustrate the use of Bokeh inside the Jupyter
notebook. To view the examples here, first execute 'jupyter notebook' in this
directory. A web browser should automatically open up to the Jupyter Dashboard
at localhost:8888 (or you may navigate there manually). Click on any of the
notebooks listed to open and explore.
