
input = open ("sequences1.txt", "r")
out = open ("trimmed_seqs.txt", "w") 
for line in input:
	seq = line.rstrip ('n')
	length_before = len (line)
	trim = seq [3:length_before]
	out.write (trim.upper())
input.close()
out.close ()

inp = open ("sequences1.txt", "r")
output = open ("trim_stats.txt", "w") 
for line in inp:
	clean = line.rstrip ("\n")
	length_before = len (clean)
	trim = line[5:length_before]
	length_after = len (trim)
	Acontent = trim.count ("a")
	Tcontent = trim.count ("t")
	AT = Acontent+Tcontent
	percent = round((AT/length_after)*100,1)
	output.write ("The length before trimming is " + str(length_before) + "\t" + \
	"after trimming is " + str (length_after) + "\t"+\
	"AT content is "+ str(percent) +"\n" )
inp.close()
output.close ()


