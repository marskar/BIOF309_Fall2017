from __future__ import division
#open the input file
my_file = open("/Users/sulee/Desktop/python_309/sequences1.txt")
my_file_contents = my_file.read()
my_dnai = my_file_contents.split()
my_dna = "".join(my_dnai)
print(my_dna)

# open the output file
output = open("/Users/sulee/Desktop/python_309/trimmed_seqs.txt", "w")
# go through the input file one line at a time
for dna in my_dna:
    # calculate the position of the last character
    last_character_position = len(my_dna)
    # get the substring from the 15th character to the end
    trimmed_dna = my_dna[10:last_character_position]
    # print out the trimmed sequence
    output.write(trimmed_dna.upper())
    # print out the length to the screen
    print("processed sequence with length " + str(len(trimmed_dna)))
    output.close()

my_file = open("/Users/sulee/Desktop/python_309/sequences1.txt")
my_file_contents = my_file.read()
my_dna1 = my_file_contents.split()
my_dnai = "".join(my_dna1)
my_dna = my_dnai.upper()
print(my_dna)
output = open("/Users/sulee/Desktop/python_309/trim_stats.txt", "w")
for dna in my_dna:
    last_character_position = len(my_dna)
    trimmed_dna = my_dna[10:last_character_position]
#error
    length = len(trimmed_dna)
    a_count = my_dna.count('A')
    t_count = my_dna.count('T')
    at_content = (a_count + t_count) / length * 100
    output.write("The length of sequence before trimming is " + str(last_character_position) + '\n' + "The length of sequence after trimming is " + str(length) + '\n' + "A count in trimmed sequence: " + str(a_count) + '\n' + "T count in trimmed sequence: " + str(t_count) + '\n' + "AT content in trimmed sequence is " + str(at_content) + " %" + '\n')
    output.close()
