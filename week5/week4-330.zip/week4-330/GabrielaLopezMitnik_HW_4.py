#command lin in windos powershell it is:
#py.exe GabrielaLopezMitnik_HW_4.py sequences1.txt

#homework 4
#1 print the length of each line
import sys
file = open(sys.argv[1],"r")
for dna in file:
    last_character_position = len(dna)
    print ("the Length is: "+ str(last_character_position))
 #2 print the length between 0 and 12 in each line
    trimmed_dna = dna[0:12]
    last_character_short = len(trimmed_dna)
    print ("the Length between 0 and 12 is: "+ str(last_character_short))
file.close

#3.a generating output files
#3.a trimmed_seqs.txt, only the first 12 characters
newfile = open(sys.argv[1],"r")
my_file = open("trimmed_seqs.txt", "w")
for dna in newfile:
       trimmed_dna = dna[0:12]
       my_file.write(trimmed_dna)
       my_file.write('\n')
my_file.close()
newfile.close()
#3.i generating output files
#3.ii all seqs in upercase
newfile = open(sys.argv[1],"r")
my_file = open("upper_seqs.txt", "w")
for dna in newfile:
       my_file.write(dna.upper())
       my_file.write('\n')
my_file.close()
newfile.close()
#3.b and 4  stats
newfile = open(sys.argv[1],"r")
my_file = open("trim_stats.txt", "w")
for dna in newfile:
       last_character_position=len(dna)
       last_character_short = len(dna[0:12])
       at_count = dna[0:12].count('AT')
       my_file.write("the Length of the seq is: "+ str(last_character_position)+', '+ "the Length of seq after trimming 12 is: "+ str(last_character_short)+', '+"the AT content of the trimmed seq is: "+ str(at_count)+'\n')
newfile.close
my_file.close
