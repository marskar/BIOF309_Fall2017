# BIO309 Spring 2017
# 3:30 pm class
# Home Work 3
# Deven Shah
# Program to create MULTI-FASTA file


my_file = open('DNA.txt', 'w')
# new_dna = my_file.read().rstrip('\n')
# dna_length = len(new_dna)
new_dna1 = "ABC123              ATCGTACGATCGATCGATCGCTAGACGTATCG"
new_dna2 = "DEF456              actgatcgacgatcgatcgatcacgact"
new_dna3 = "HIJ789              ACTGAC-ACTGT--ACTGTA----CATGTG"
my_file.write(">" + new_dna1[0:6] + "\n")
my_file.write(new_dna1[20:9999].upper().replace("-","") +"\n")
my_file.write(">" + new_dna2[0:6] + "\n")
my_file.write(new_dna2[20:9999].upper().replace("-","") +"\n")
my_file.write(">" + new_dna3[0:6] + "\n")
my_file.write(new_dna3[20:9999].upper().replace("-","") +"\n")
my_file.close()
