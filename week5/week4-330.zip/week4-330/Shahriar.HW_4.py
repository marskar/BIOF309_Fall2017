#Your homework is to extend the script generated in the first exercise.
#The script you will turn in will trim the sequences in
#Python/HW_1/sequences1.txt. Your script must:
#1) Take a command line argument for the trimming length and print that length
#to the screen.
#a. I showed you how to incorporate command line arguments in class and an
#example script is found the sys_argv.py
#2) Function properly on any length between 0 and 12.
#3) Generate two output files:
#a. The first file is the trimmed sequences and should be called:
#i. trimmed_seqs.txt
#ii. All sequences should be in upper case!
#b.The second will contain stats on the trimmed sequences all on separate lines.
#i. File should be called: trim_stats.txt
#4) The trimmed stats file must contain please include usefule descriptions
#as well as the numbers:
#a. The length of the sequence before trimming.
#b. The length of the sequence after trimming
#c. The AT content of the trimmed sequence
#5) Extra credit: Return only 3 digits for the AT content

import sys #usuage [script_name].py [trim length]

# open the input file and output files
my_dna = open("sequences1.txt", "r")
trimmed_seqs = open ("trimmed_seqs.txt", "w")
trimmed_stats = open ("trimmed_stats.txt", "w")
print("the trim length is : " + str(sys.argv[1]))

for line in my_dna:
    #find sequence legnth and the last position
    seq_length = len(line)
    #get the number of bases that needed to be trimmed, and trim the sequence
    trimmed_seq = line[int(sys.argv[1]):seq_length].upper()
    trimmed_len = len(trimmed_seq)
    #write trimmed sequence
    trimmed_seqs.write(trimmed_seq)
    #AT content of trimmed sequence
    A_count = (trimmed_seq.count("A")) #A_count = no. of A
    T_count = (trimmed_seq.count("T")) #T_count = no. of T
    AT_count = A_count + T_count
    AT_count_percent = round((AT_count / trimmed_len) * 100,1)
    trimmed_stats.write("the length of the sequence before trimming = "\
                                + str(seq_length) + "\n"\
                        "the length of the sequence after trimming = "\
                                + str(trimmed_len) + "\n"\
                      + "The AT content of the trimmed sequence is: "\
                                + str(AT_count_percent)\
                                + " %" + "\n" + "\n")
my_dna.close()
trimmed_seqs.close()
trimmed_stats.close()
