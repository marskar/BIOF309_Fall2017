import sys
#get length for truncation
length = sys.argv[1]
#open sequence files and create two output files)
file = open("sequences1.txt")
output1 = open("trimmed_seqs.txt","w")
output2 = open("trim_stats.txt","w")
#loop to generate output files
for line in file:
    #truncate line
    truncated = line[int(length.strip("\n")):-1]
    #count A and T to calculate AT content
    A = truncated.upper().count("A")
    T = truncated.upper().count("T")
    total = len(truncated)
    Percent = ((A+T)/total)*100
    #outputs
    output1.write(truncated.upper() + "\n")
    output2.write("length of the sequence before trimming is: " + str(len(line)-1) + "  length of the trimmed sequence is: " + str(len(truncated)))
    output2.write("  the AT content of the trimmed sequence is: " +str(round(Percent,1)) + "% \n")
#close files
file.close()
output1.close()
output2.close()
