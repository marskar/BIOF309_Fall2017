#This allows for a user input at the command line, defining the trim length
import sys
trim = sys.argv[1]
trim = int(trim)
#This opens the fine containing the original sequences
dnafile = open("input.txt", "r")
#This opens two output files to write to
file_output = open('trimmed_seqs.txt', 'w')
file_stats = open('trim_stats.txt', 'w')
x = 1
for line in dnafile:
    #This Decides the length of the string, and what portion to trim
    last_position = len(line)
    trimmed = line[trim:last_position]
    #This writes the trimmed sequences to a new file, capitalized
    trimmed = trimmed.upper()
    file_output.writelines(['Sequence ', str(x), ':', '\n', trimmed, '\n'])
    #This finds the length of the trimmed sequence and its AT count
    Acount = trimmed.count('A')
    Tcount = trimmed.count('T')
    newlength = len(trimmed)
    ATcount = ((Acount + Tcount) / newlength) *100
    ATcount = round(ATcount, 1)
    #This writes the old length, new length, and AT count to a stats file
    file_stats.writelines(['Sequence ', str(x), ':', '\n'])
    file_stats.writelines(['Original length: ', str(last_position), '\n'])
    file_stats.writelines(['Trimmed length: ', str(newlength), '\n'])
    file_stats.writelines(["The AT percentage is ",str(ATcount),'%','\n','\n'])
    #This will number each sequence, starting from 1, and increment it.
    x = x+1
#This closes the files
file_output.close()
file_stats.close()
print('Task complete.')
