#creat or open the files
my_file = open('sequences1.txt')
output1= open("trimmed_seqs.txt", "w")
output2=open("trim_stats.txt","w")

# creat a loop
for line in my_file:
    #trim 9 bases of the sequences
    trimmed_sequence = line[9:len(line)].upper().rstrip('\n')

    # print the trimming length to the screen
    trimming_length = line[0:9]
    print("the trimming lengtht is " + trimming_length)

    # write to trimmed_seqs files
    output1.write(trimmed_sequence + "\n\n")

    #write stats to the second file
    output2.write(trimmed_sequence + "\n")
    output2.write("the length of the sequence before trimming is " + \
    str(len(line)) + "\n")
    output2.write("the length of the sequence after trimming is " + \
    str(len(trimmed_sequence)) + "\n")
    AT_content = (trimmed_sequence.count('A') + \
    trimmed_sequence.count('T'))/len(trimmed_sequence)
    output2.write("the AT content of the trimmed sequence is " + \
    str(round(AT_content*100, 1)) +"%" +"\n\n")

# close the files
my_file.close()
output1.close()
output2.close()
