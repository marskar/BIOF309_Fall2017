#Allows division to be run in python2-used for calculating the AT percentage
from __future__ import division

#Allows command line arguments to be used later with sys.argv
import sys

#Opens the  file containing the DNA sequences that we will edit and run stats on
my_seq = open("sequences1.txt", "r")

#Opens two new files to store the trimmed sequences and statistics run on them
output1 = open("trimed_seqs.txt", "w")
output2 = open("trim_stats.txt", "w")

#Sets up a counter to later be used in the loop
counter = 1

#Sets up the command line argument
trim_to_here = int(sys.argv[1])
print("Your inputted  trimming length is: " + str(trim_to_here))

#Sets the command line argument to only function on a value from 0 to 12
if trim_to_here >=0 and trim_to_here <= 12:

#Sets up a for loop to run when the if qualifications are satisfied
    for seq in my_seq:

#Finds the total length of every DNA sequence from the "sequences.txt" file
        total_length = len(seq)
        #print("total length is: " + str(total_length))

#Trims a specified amount of base pairs from the sequences
        my_trim = seq[trim_to_here:total_length]
        #print("trimmed length is: " + str(len(my_trim)))

#Makes all the sequences upper case
        my_upper = my_trim.upper()
        #print(my_upper)

#Finds the at content of the sequences
        a_content = my_upper.count('A')
        t_content = my_upper.count('T')
        at_content = a_content + t_content
        #print("at content is: " + str(at_content))

#Finds at percentage
        at_percent = ((at_content / len(my_upper)) * 100)
        #print("The at percent is: " + (str(round(at_percent,1))))

#Writes the trimmed sequences to the "trimmed_seqs.txt" file
        output1.write("Sequence " + str(counter) + ": ")
        output1.write(my_upper + '\n')

#Writes the sequence number above the stats
        output2.write("Sequence " + str(counter) + " stats: ")

#Writes the stats to the "trim_stats.txt" file
        output2.write('\n' + "The untrimmed length is: " + str(total_length) + " base pairs. " + '\n')
        output2.write("The trimmed length is: " + str(len(my_trim)) + " base pairs.")
        output2.write('\n' + 'The AT percentage of the sequence is: ' + (str(round(at_percent,1))) + "%" + '\n' + '\n')

#Adds 1 to the counter for writing to the "trim_stats.txt" file
        counter = counter + 1

#If the inputted number is not in the range, prints an error message
else:
    print("This is an invalid trimming length, please try again. The trimming length must be between 0 and 12.")

#Closes all of the files used in the script
output1.close()
output2.close()
my_seq.close()
