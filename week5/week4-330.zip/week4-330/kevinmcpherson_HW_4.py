# Code written by Kevin McPherson
# Last edited on 7 Mar 2017

import sys

# First, let's take the command line argument and print the trim length in
# a read-out that the user will see
print ("This script will trim ", sys.argv[1], "base(s) from the sequences in"\
       " the input file")

# Next, let's open the input file we're working with
hw_seqs = open("sequences1.txt")

# Let's open our two output files, the first with the trimmed sequence
# and the second with the stats on the trimmed sequences
trim_seqs = open("trimmed_seqs.txt", "w")
trim_stats = open("trim_stats.txt", "w") 

# Go through the input file one sequence at a time
for dna in hw_seqs:
    
# Calculate the length of the sequence before trimming
    last_base_position = len(dna)
    
# Trim a substring from the command line prompt character position to the end
    trimmed_dna = dna[int(sys.argv[1]):last_base_position]

# Count the amount of A's in the current trimmed sequence
    A_count =  trimmed_dna.count("A")
    
# Count the amount of T's in the current trimmed sequence
    T_count =  trimmed_dna.count("T")
    
# Sum the A's and T's in the current trimmed sequence to get AT total
    AT_total = A_count + T_count
    
# Calculate AT content via a percentage to be reported in the trim_stats file
    AT_percentage = (AT_total/last_base_position)*100

# Round the AT percentage to 3 decimals
    AT_rounded = round(AT_percentage, 1) 

# Write upper case sequences to the trimmed sequences file
    trim_seqs.write(trimmed_dna.upper())

# Write the length of the sequence before trimming to the trim_stats file
    trim_stats.write("The length of the sequence before trimming is " + str(last_base_position) + '\n')
    
# Write the length of the sequence after trimming to the trim_stats file
    trim_stats.write("The length of the sequence after trimming is " + str(len(trimmed_dna)) + '\n')

# Write the AT percentage in 3 decimal points
    trim_stats.write("A's and T's make up " + str(AT_rounded) + \
    "% of the the sequence." + '\n')

# Print out a running script to the screen
    print("Processed sequence with length " + str(len(trimmed_dna)))
