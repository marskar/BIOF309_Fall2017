# BIO309 Spring 2017
# 3:30 pm class
# Home Work 4
# Deven Shah
# Program to trim sequences to required lenghth and report statistics

# seek user input for trim length
import sys
trimming_length = int(sys.argv[1])

# define input and output files
sequences = open("sequences1.txt","r")
trimmed_seqs = open("trimmed_seqs.txt", 'w')
trim_stats = open("trim_stats","w")

# read one line at a time
for line in sequences:
    # strip the end of line character
    dna_seq = line.rstrip("\n").upper()

    # find length
    seq_length = len(dna_seq)

    # set trim length to the minimum os user supplied or seq length
    trim_length = min(trimming_length,seq_length)

    # trim sequence
    trimmed_seq = dna_seq[0:trim_length]

    # get length of trimmed sequence
    trim_seq_len = len(trimmed_seq)

    # write files
    trimmed_seqs.write(trimmed_seq+"\n")
    trim_stats.write("Length of sequence before trimming is " + str(seq_length) + ", ")
    trim_stats.write("after trimming is " + str(trim_seq_len)+", & ")
    trim_stats.write("the 'AT' content in trimmed sequence is "+
     str(round((trimmed_seq.count('A')+trimmed_seq.count('T'))/trim_seq_len*100,1)) +"%\n")
