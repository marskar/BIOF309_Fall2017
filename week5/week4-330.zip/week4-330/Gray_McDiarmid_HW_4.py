#import what is needed at the top
import sys

#open sequence containing file
seqlist = open('sequences1.txt', 'r')

#define an integer for the sys.argv input
trimlen = int(sys.argv[1])

#establish a loop per line
for line in seqlist :
    #convert line to upper case
    Uline = line.upper()
    #slice with sys.argv variable to trim the line to specified length
    Tline = Uline[trimlen:]
    #open a file to write the trimmed line, write/append the line, close
    trimwrite = open('trimmed_seqs.txt', 'a')
    trimwrite.write(Tline)
    trimwrite.close()
    #open a seperate .txt file to give facts about your line
    factswrite = open('trim_stats.txt', 'a')
    #use the pre/post trim variables to give required length information
    factswrite.write("This line once contained " + str(len(Uline)) + " bases,")
    factswrite.write(" after trimming, it has " + str(len(Tline)) + " bases,")
    #calculate AT content per line, post trim
    at_count = Tline.count("A") + Tline.count("T")
    at_percentage_unrounded = (at_count/len(Tline))*100
    #round to 3 digits (one digit past the decimal)
    at_percentage = round(at_percentage_unrounded, 1)
    #write AT content to file and make a new line for the next loop
    factswrite.write(" with an AT content of " + str(at_percentage) + "% \n")
    #close the file
    factswrite.close()
