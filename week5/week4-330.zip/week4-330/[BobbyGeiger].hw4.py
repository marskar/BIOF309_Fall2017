#opens the file sequences .txt and creates a file to write the results of the loop into.
file = open("sequences.txt")
output = open("trimmed_seqs.txt", "w")

#loop that reads and trims each DNA sequence seperately according to the argument in command line.
#Then writes the data to a file.
for dna in file:
    import sys
    last_character_position=len(dna)
    trimmed_dna=dna[int(sys.argv[1]):last_character_position]

#results of the loop are written to a file
    output.write("\n"+"original sequence: "+ dna.upper()+
    "processed sequence with length: "+ str(len(trimmed_dna))+"\n")

#answer is printed out
    print(dna.upper()+ "processed sequence of length: " + str(len(trimmed_dna))+"\n")

#closes the file the loop was witten in
output.close()
file.close()

#opens the file again and the next line creates another file to write the results of another loop into
file=open("sequences.txt")
output2 = open("trim_stats.txt", "w")

#loop that reads each DNA sequence before and after it is trimmed.
#also trims the DNA sequence according to the argument in command line.
#the loop also counts the number of A's and T's in each of the sequnce.
for dna in file:
    beforelength=str(len(dna))
    print(dna.upper() + "length of sequence before trimming: " + beforelength)

    import sys
    last_character_position=len(dna)
    trimmed_dna=dna[int(sys.argv[1]):last_character_position]

    A_count = dna.count("A")
    T_count = dna.count("T")
    A_and_T_count = (A_count)+(T_count)

    amount_A_and_T = (A_and_T_count)/(last_character_position)
    percentage_of_A_and_T = (amount_A_and_T)*100

#answer is printed out
    print("length of sequence after trimming " + str(len(trimmed_dna))+"\n"+
    "The amount of A and T in my sequence is " + str(round((percentage_of_A_and_T)))+
    "%"+"\n")

#results of the loop are written to a file
    output2.write("\n" + dna.upper() + "Length of sequence before trimming: " +
    beforelength + "\n"+ "Length of DNA after trimming: " +
    str(len(trimmed_dna))+"\n"+"The amount of A and T in my sequence is " +
    str(round((percentage_of_A_and_T)))+"%"+"\n")

#closes the file the loop was written into
output2.close()
file.close()
