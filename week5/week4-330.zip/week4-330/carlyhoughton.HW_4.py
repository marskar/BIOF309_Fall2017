import sys
#usuage [script_name].py [trim length]

# open the input file and output files
my_dna = open ("sequences1.txt", "r")
trimmed_dna = open("trimmed_seqs.txt",'w')
trimmed_stats = open ("trim_stats.txt", "w")
print("trim length: " + str(sys.argv[1]))

#go through the input file one line at a time
for line in my_dna:

    #trim sequence
    last_position = len(line)
    trimmed_seq = line[int(sys.argv[1]):last_position].upper()
    trimmed_length = len(trimmed_seq)

    #calculate AT content for trimmed sequence
    AT_count = trimmed_seq.count("A") + trimmed_seq.count("T")
    AT_content = round(100*(AT_count/trimmed_length),3)

    #write trimmed sequence to file
    trimmed_dna.write(trimmed_seq)

    #write trim stats to corresponding file
    trimmed_stats.write("trimmed sequence: " + str(trimmed_seq))
    trimmed_stats.write("Length before trimming: " + str(last_position) + "\n")
    trimmed_stats.write("The trimmed length is: " + str(trimmed_length) + "\n")
    trimmed_stats.write("The AT content is: " + str(AT_content) + "%" + "\n")

trimmed_dna.close()
trimmed_stats.close()
