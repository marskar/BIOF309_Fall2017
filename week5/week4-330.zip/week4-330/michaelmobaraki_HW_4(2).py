# allows you to add arguments to the command line
import sys 

print("argument addded name: ", sys.argv[1])# by having one i don't count my argument which is my title michael hw

print("The arguments names: " , str(sys.argv) + "\n") # so if you enter a number it should print out that number as a string

from six.moves.urllib.request import urlopen # allows the the sequences to be downloaded from online if link expires go to the sequences in green 
link = "https://raw.githubusercontent.com/ianmisner/BIO309_Spring2017/master/week4/sequences1.txt"
linktxt = urlopen(link) # this urlopen uses a method that is imported from urllib allows me to open link contents
content = linktxt.read() # i can read the link or i can make changes just subsitute read with write


rawseq = str(content)
rawupper = str(rawseq.upper())
removeN =str(rawupper.replace("N", ",").replace("B'", "").replace("'", "").replace("R", ""))
sequences = removeN.replace("\\", "")
#print(sequences) if you want to see sequences

#sequences = "AGtatgactcccAggcataGGGGCAGATGA,GGCCCAAGACATTAGACTAGCATTTTTTTTGAGCCCAGAGATAGACAGA,AGTTGATGACGAT,ggcagrcttgacta,GGCCCAAGACATTAGACTAGCATTTTTTTTGAGCCCAGAGATAGACAGAGGCCCAAGACATTAGACTAGCATTTTTTTTGAGCCCAGAGATAGACAGAGGCCCAAGACATTAGACTAGCATTTTTTTTGAGCCCAGAGATAGACAGA,cccaaattttttttgcaggatca,ATGATGATGATGATGATGCATGATGCATGC,GCCGCGCGTAGTCAATAGCTATAGGCTAGTAGTACgatgatcata,GACGATGCCAAATATATGGGAGGATAGGGGATTCCCCC,aTaTtttacgTGACtagcccgagtga"

# in case link fails use the variable "sequences" above

 
variable = sequences.split(",")
print("you have this many diffrent sequences " + str(len(variable))) # len returns the length of the number of items in a list or object

start = int(sys.argv[1])


trimseq = open("trim_seqs.txt", "w")
for nucleotide in variable:
	trimseq.write( "Sequence Before Trimming " + "\n" + str(nucleotide) + "\n")
	trimseq.write("Trimmed " + "\n" + str(nucleotide[start:]) + "\n" + "\n")




trimstat = open("trim_stats.txt", "w")
for nucleotide in variable: # by selecting nucleotide i select for each charecter within the list 
	trimstat.write( "Sequence Before Trimming " + "\n" + str(nucleotide) + "\n") # writes my sequences in a loop
	Adenine = str(nucleotide.count("A")) # counts m A contenents 
	Thyronine = str(nucleotide.count("T")) # counts my T contents 
	length = str(len(nucleotide)) # gives the length of the sequence 
	AT = str(int(Adenine) + int(Thyronine))
	try:# lets you exclude any value that is 0/0 or continue with exceptions 
		PercentAT = str((int(AT)/int(length))*100)# gives you ur percentage 
	except ZeroDivisionError :
		print("you are amazing")
	trimstat.write( "length of seq Before trimming " + "\n" + str(len(nucleotide)) + "\n")
	trimstat.write( "AT count Before trimming " + "\n" + AT + "\n")
	trimstat.write( "AT percent Before trimming " + "\n" + PercentAT + "%" + "\n" + "\n")
	
# below is the loop for the trim sequence 
	trimstat.write("\n" + "Trimmed " + "\n" + str(nucleotide[start:]) + "\n")
	Adenine = str(nucleotide[start:].count("A"))
	Thyronine = str(nucleotide[start:].count("T")) 
	length = str(len(nucleotide[start:])) 
	AT = str(int(Adenine) + int(Thyronine))
	try: # lets you exclude any value that is 0/0 or continue with exceptions 
		PercentAT = str((int(AT)/int(length))*100) # gives you ur percentage 
		#rpercentAT = round((int(PercentAT)), 2) # need to come back and figure rounding.. 
	except ZeroDivisionError :
		print("")
	trimstat.write( "length of Trimmed Seq " + "\n" + str(len(nucleotide[start:])) + "\n")
	trimstat.write( "AT count After trimming " + "\n" + AT + "\n")
	trimstat.write( "AT percent of Trimmed seq" + "\n" + PercentAT + "%" + "\n" + "\n")

	
trimseq.close()
trimstat.close()

