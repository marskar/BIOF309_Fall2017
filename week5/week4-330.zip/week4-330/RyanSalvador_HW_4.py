import sys
## opens sys file in position 1
seqs = open(sys.argv[1], "r")

## makes new files
trimmed_seqs = open("trimmed_seqs.txt", "w")
stats_seqs = open("trim_stats.txt", "w")

##starting loop
for seq in seqs:
    ##trimming sequences
    SEQ = seq.upper()
    last_character_position = len(SEQ)
    trimmed_seq = SEQ[int(sys.argv[2]):last_character_position]
    ## writes trimmed sequences to trimmed_seqs file
    trimmed_seqs.write(trimmed_seq)
    ##calculating AT content
    total_NT = len(trimmed_seq)
    total_A = trimmed_seq.count('A')
    total_T = trimmed_seq.count('T')
    total_AT = total_A + total_T
    total_AT_100 = total_AT * 100
    percent_AT = total_AT_100 / total_NT
    ## writes stats to stats_seqs file
    stats_seqs.write("Sequence BEFORE is " + str(len(SEQ)) + "\n"
    + "Processed sequence AFTER is " + str(len(trimmed_seq)) + "\n"
    + "The AT content of the trimmed sequence is " + str(percent_AT) + "%.")
    #print("Sequence BEFORE is " + str(len(SEQ)))
    #print("Processed sequence AFTER is " + str(len(trimmed_seq)))
    #print("seq is " + str(trimmed_seq))
    #print("The AT content of the trimmed sequence is " + str(percent_AT) + "%.")

##closes files
trimmed_seqs.close()
stats_seqs.close()
