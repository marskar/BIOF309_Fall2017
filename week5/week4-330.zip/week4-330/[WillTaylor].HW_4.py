import sys
#command line argument I need
trim = sys.argv[1]
#open up and get ready to write the files
file = open("sequences1.txt")
output = open("trimmed_seqs.txt", "w")
output2 = open("trim_stats.txt", "w")
for dna in file:
#define the length of the original sequence and make everything uppercase
 last_character_position = len(dna)
 dna = dna.upper()
 #so here's my problem. I don't know why the trim variable doesn't work. if you replace it with a number the code works perfectly, which I hope counts for something...
 trimmed_dna = dna[trim:last_character_position]
#making a variable for the new length and the AT/total 
 trim_length = len(trimmed_dna)
 A = trimmed_dna.count('A')
 T = trimmed_dna.count('T')
 AT = (A + T)
#the division so I can have a nice rounded % and another option to avoid dividing by 0 in case that you trim the sequence to 0 
 if trim_length > 1:
    AT_content = float(AT) / trim_length  *100
    AT_content = round(AT_content, 1)
 else:
     AT_content = ("N/A")
#writing our new files and making sure they have everything necessary
 output.write(trimmed_dna.upper())
 output2.write("The length of the sequence before trimming: " + str(last_character_position) + "\n" + "The length of the sequence after trimming: " + str(trim_length) + "\n" + "The AT content is: " + str(AT_content) + "%" + "\n" + "\n")
#this is the part that really confuses me because this successfully prints out 'trim' but earlier this variable doesn't work
print(trim)
