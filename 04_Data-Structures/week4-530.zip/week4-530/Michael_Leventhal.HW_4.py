import sys

#open input.txt
input = open("sequences1.txt")

#opens/creatse output files
output1 = open("trimmed_seqs.txt", "w")
output2 = open("trim_stats.txt", "w")

for seq in input:
    #corrects all sequences to upper case
    upper_seq = seq.upper()
    #rstrip spaces
    cleaned_upper_seq= upper_seq.rstrip("\n")
    #remove a number of bases from each line, specified via command line
    length_seq = len(cleaned_upper_seq)
    specified_trim = sys.argv[1]
    trimmed_cleaned_upper_seq = cleaned_upper_seq[int(specified_trim):length_seq]
    #write trimmed and corrected sequences to output1
    output1.write(trimmed_cleaned_upper_seq + "\n")
    length_trimmed_seq = len(trimmed_cleaned_upper_seq)
    #print the length of each trimmed sequence
    print("Trimmed sequence length: " + str(length_trimmed_seq))
    #determine AT count
    absolute_AT = trimmed_cleaned_upper_seq.count("A") + \
    trimmed_cleaned_upper_seq.count("T")
    percent_AT = absolute_AT*100/length_trimmed_seq
    rounded_percent_AT = round(percent_AT, 1)
    #write stats to output2
    output2.write("Length of sequence before trimming: " + str(length_seq) + "\n" +
    "Length of sequence after trimming: " + str(length_trimmed_seq) + "\n" +
    "AT content: " + str(rounded_percent_AT) + "%\n\n")
#print the number of bases trimmed
print("Number of bases trimmed: " + str(specified_trim))

input.close()
output1.close()
output2.close()
