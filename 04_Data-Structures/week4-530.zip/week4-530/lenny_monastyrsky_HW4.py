import sys
### USAGE
# script_name [input_file_name] [trim length]
sequences = open(sys.argv[1], "r")
trimmed_seq = open("trimmed_seq.txt", "w")
trim_stats = open("trim_stats.txt", "w")
trimming_length = int(sys.argv[2])
if not 0 <= trimming_length <= 12:
	print("Trimming length must be between 0 and 12 inclusive")
	exit()
print("\n" + "Trimming length as entered: " + str(trimming_length) + "\n")
for seq in sequences:
	trim_stats.write("The length of the sequence before trimming: " + str(len(seq.rstrip("\n"))) + "\n")
	my_trimmed = seq[trimming_length:].upper()
	my_trim = my_trimmed.rstrip("\n")
	trim_stats.write("The length of the sequence after trimming: " + str(len(my_trim)) + "\n")
	percentage_A = round((my_trim.count("A")/(len(my_trim))*100), 1)
	trim_stats.write("Percentage of A in trimmed sequence: " + str(percentage_A) + "%" + "\n")
	percentage_T = round((my_trim.count("T")/(len(my_trim))*100), 1)
	trim_stats.write("Percentage of T in trimmed sequence: " + str(percentage_T) + "%" + "\n")
	trim_stats.write("==============================\n")
	trimmed_seq.write(my_trim + "\n")
	
sequences.close()
trimmed_seq.close()
trim_stats.close()
