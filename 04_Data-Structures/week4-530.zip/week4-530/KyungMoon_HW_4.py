#
import sys
#######USUAGE
# KyungMoon_HW_4.py [file output name]

#collect the starting sequence information
in_file = open(sys.argv[1],"r")

#open output files
out=open("trimmed_seqs.txt","w")
out1=open("trim_stats.txt","w")

#write the loop function
for seq in in_file:
    before_length_of_seq = len(seq)
    my_seq = seq.upper()
    my_cleaned = my_seq.rstrip('\n')
    my_trim = my_cleaned[6:] # trimmed out the sequence between 1 and 6

    trimmed_length = len(my_trim)

    A_count = my_trim.count("A")
    T_count = my_trim.count("T")
    AT_content = ((A_count + T_count)/trimmed_length) *100

#write output files
    out.write(my_trim + "\n")
    out1.write("The sequence length before trimming is: " + str(before_length_of_seq)+"\n"
               "The trimmed length is: " + str(trimmed_length)+"\n"
               "the A content is: "+str(A_count)+"\n"
               "the T content is: "+str(T_count)+"\n"
               "The AT content of the trimmed seqeunce is: " + str(round(AT_content, 3)) +"%" +"\n")

in_file.close()
out.close()
out1.close()
