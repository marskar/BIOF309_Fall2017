#####################Exercise 1 from chapter 4 of P4B#######################
preprocess_dna= open("input.txt")

#open the file

clean_dna= open("clean_dna.txt", "w")

#create file to place cleaned dna

for dna in preprocess_dna:
    count=len(dna)
    #count the number of bases
    strip_dna= dna.rstrip("\n")
    #remove new line characters
    trim=strip_dna[14:count]
    #remove the adapter sequence
    clean_dna.write(trim + "\n")
    #write the sequence to a file
    clean_count= len(trim)
    #get official count of DNA
    print("The length of my dna is " + str(clean_count))
    #print a statement for each line with length of DNA sequence


preprocess_dna.close()
clean_dna.close()

#######TRIM CLEANED DNA USING A COMMAND LINE ARGUMENT
##############PRINT NUMBER OF BASES TRIMMED TO THE SCREEN
##############WRITE NEW FILE FOR TRIMMED DNA
###############WRITE NEW FILE FOR TRIMMED DNA STATS
import sys
#open file that will be trimmed
dna_to_trim= open("clean_dna.txt").read()


#calculate length of DNA before trimming
dna_pre_length= len(dna_to_trim)


#trim the sequence based on command line input
new_dna= dna_to_trim[int(sys.argv[1]): int(dna_pre_length)]


#print trim length
print("The trimming length is " + sys.argv[1])


#create new file that stores trimmed dna
trim_seq= open("trimmed_seqs.txt", "w")
trim_seq.write(new_dna)
trim_seq.close()



#calculate length after trimming
dna_post_trim= len(new_dna)

#calculate A and T content of trimmed DNA
A_count= new_dna.count("A")
T_count= new_dna.count("T")
totalAT= A_count + T_count

#calculate AT percentage of trimmed
AT_percentage= round((totalAT)/(dna_post_trim), 3)


#create new file for writing trimmed stats
stat_dna= open("trim_stats.txt", "w")
#write the stats of trimmed and pretrimmed DNA
stat_dna.write("The length of the sequence before trimming is " + \
str(dna_pre_length) + "\n")
stat_dna.write("The length of the sequence after trimming is " + \
str(dna_post_trim) + "\n")
stat_dna.write("The AT content of the trimmed sequence is " + \
str(AT_percentage) + "\n")
