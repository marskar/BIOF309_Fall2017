#HW_4
###USAGE
# Hamed_Kooshapur_HW_4.py trimming length

import sys

input = open("sequences1.txt", "r")
output1 = open("trimmed_seqs.txt", "w")
output2 = open("trim_stats.txt", "w")

print("The trimming length is: ", sys.argv[1])

for dna in input:
   
   length_of_dna = len(dna)
   my_cleaned = dna.rstrip('\n')

   my_trim = my_cleaned[int(sys.argv[1]):length_of_dna] #or [14:]

   output1.write(my_trim.upper() + "\n")
   
   trimmed_length = len(my_trim)

   print("The trimmed length is: " + str(trimmed_length))

   A_count = my_trim.count("A")
   T_count = my_trim.count("T")
   AT_count = A_count + T_count
   AT_content = 100 * (AT_count/trimmed_length)


   output2.write("The length of sequence before trimming is: " + str(length_of_dna) + "\n")
   output2.write("The length of sequence after trimming is: " + str(trimmed_length) + "\n")
   output2.write("The AT content of the trimmed sequence is " + str(AT_content) + "\n")

input.close()
output1.close()
output2.close()
