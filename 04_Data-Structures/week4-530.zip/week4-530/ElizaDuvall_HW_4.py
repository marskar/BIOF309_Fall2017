##### HOMEWORK NOTES #####
#1 open file (input.txt)
#2 open new file
#3 remove the first 14 bases
#4 print the length of trimmed
#5 loop numbers 3 and 4

#open input file
my_file = open("/Users/erduvall/Desktop/Python/input.txt")

#save in output for some reason
output = open("/Users/erduvall/Desktop/Python/trimmed_seq.txt", "w")

#start loop
for dna in my_file:
    #calculate position of last character
    last_character_position = len(dna)
    #acquire the strong from position 15 to the end
    trimmed_dna = dna[14:last_character_position]
    #print trimmed sequence
    output.write(trimmed_dna)
    # print out the length to the screen
    output.write("the trimmed sequence length is " + str(len(trimmed_dna)))

    import sys

    print("This is the length of the sequence: ", len(sys.argv))

#AT Content
AT_content = open("/Users/erduvall/Desktop/Python/trim_stats.txt", "w")

for find_AT_Content in my_file:

    full_length = len(find_AT_Content)

    A_count = find_AT_Content.count('A')

    T_count = find_AT_Content.count('T')

    AT_count = (A_count) + (T_count)

    total_AT_content= ((AT_count)/(full_length)*100)

    AT_content.write("The length of the sequence before trimming was: " + (last_character_position))

    AT_content.write("The length of the sequence after trimming was: " + (trimmed_dna))

    AT_content.write("The AT content of the trimmed sequence was: " + str(total_AT_content) + " percent.")
