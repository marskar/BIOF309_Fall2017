# Joseph Hurley
# Week 4 Homework

# USAGE: josephhurley_HW_4.py [trim_length]

################################################################################

# import packages

import sys

# globals

trim_length = int(sys.argv[1])

# main

input_file = open("sequences1.txt", "r")
trimmed_seqs = open("trimmed_seqs.txt", "w")
trim_stats = open("trim_stats.txt", "w")

print(str(trim_length) + " characters will be trimmed from the beginning of each sequence.")
if (trim_length < 0) | (trim_length > 12):
    print("Trim length is not between 0 and 12. Proceed with caution.")

count = 1
for line in input_file:
    trimmed_line = line.rstrip("\n")[trim_length:].upper()
    trimmed_seqs.write(trimmed_line + "\n")
    trim_stats.write("Statistics for sequence on line " + str(count) + ":\n")
    trim_stats.write("\tLength of initial sequence: " + str(len(line.rstrip("\n"))) + "\n")
    trim_stats.write("\tLength of trimmed sequence: " + str(len(trimmed_line)) + "\n")
    AT_percent = 100 * (trimmed_line.count("A") + trimmed_line.count("T")) / len(trimmed_line)
    trim_stats.write("\tAT percent of trimmed sequence: " + str(round(AT_percent, 3)) + "\n\n")
    count += 1

input_file.close()
trimmed_seqs.close()
trim_stats.close()
