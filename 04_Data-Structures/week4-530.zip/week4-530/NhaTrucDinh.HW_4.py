
#use sys in order to pass user inputs into script
import sys
#open sequence file
dna_file = open("sequences1.txt",'r')
#open two files to write into
trimmed_file= open("trimmed_seqs.txt",'w')
stats_file=open("trim_stats.txt",'w')
#initiate a sequence number for labeling
seqnumber=1
#use a for loop to go through each line in the sequence file
for dna in dna_file:
    #take out new line character in order to count bases accurately
    cleaned=dna.rstrip("\n")
    #count original length
    original_length=len(cleaned)
    #clip the desired amount to the end of the sequence
    new_dna=cleaned[int(sys.argv[1]):original_length]
    #write new sequence into trimmed file and add new line character; make all sequences uppercase
    trimmed_file.write(new_dna.upper()+"\n")
    new_dna=new_dna.upper()
    #get length of new trimmed DNA
    trimmed_length=len(new_dna)
    #Count the number of A's and T's and sum; then divide by total length to get percentage
    ATpercent=((new_dna.count("A")+new_dna.count("T"))/trimmed_length)*100
    #round AT percentage to 3 decimals
    ATpercent=round(ATpercent,3)
    #write to statistics file
    stats_file.write("Sequence "+str(seqnumber)+"\n")
    stats_file.write("Original Sequence: "+dna.upper())
    stats_file.write("Trimmed Sequence:  " +new_dna.upper()+"\n")
    stats_file.write("Length of sequence before trimming: "+str(original_length)+"\n")
    stats_file.write("Length of sequence after trimming: "+str(trimmed_length)+"\n")
    stats_file.write("AT content after trimming: "+str(ATpercent)+"\n")
    #move on to next sequence number
    seqnumber+=1
#close files
trimmed_file.close()
stats_file.close()
dna_file.close()

