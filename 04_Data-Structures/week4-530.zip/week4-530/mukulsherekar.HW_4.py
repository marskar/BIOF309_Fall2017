import sys

print("The trim length is: ", sys.argv[1])

#opening a file
file=open("sequences1.txt")



#converting contents into a list
all_seq=file.readlines()

#writing files
output_file=open("trimmed_seqs.txt","w")
stats_file=open("trim_stats.txt", "w")

#looping
for line in all_seq:
    line=line.rstrip()
    #giving variable name to system argument 1 ie trim length and converting it to integer
    trim_lgt=int(sys.argv[1])
    #setting up trimmed seq
    new_seq=line[trim_lgt:]    
    #writing output in new files    
    output_file.write("\n"+"\n" + new_seq.upper())
    stats_file.write("\n" +"\n"+ "The length of sequence before trimming was: " + str(len(line)))
    stats_file.write("\n" + "The length of sequence after trimming is: " + str(len(new_seq)))
    #counting AT
    A=new_seq.count("A")
    T=new_seq.count("T")
    total_ntide=len(new_seq)
    fraction_AT=(A+T)/total_ntide
    percent_AT=fraction_AT*100
    stats_file.write("\n" + "The AT content of the trimmed sequence is " + str(round(percent_AT,3))+"%")
file.close()
   
    
