#Ayla Decavallas
#biof309
#Hw4

#this is needed to use system arguements
import sys


# open the input file
file = open("sequences1.txt")

# open the output file
output1 = open("trimmed_seqs.txt", "w")
output2 = open("trim_stats.txt", "w")
#take trimming length from command line and print it out
my_trimmed_length = int(sys.argv[1])
print(my_trimmed_length)

# go through the input file one line at a time
for dna in file:
	
	
    # calculate the position of the last character
	last_character_position = len(dna)
	
    # get the substring from the trimming length to the end. I trimmed it from left to right as was demoed in class
	trimmed_dna = dna[my_trimmed_length:last_character_position]
	
	#make trimmed dna uppercase
	trimmed_dna = trimmed_dna.upper() 
	
	#Calculate AT percent of trimmed dna
	at_trimmed_dna = (trimmed_dna.count('A') + trimmed_dna.count('T')) / len(trimmed_dna)
	
	#write trimmed dna to trimmed_seqs file
	output1.write(trimmed_dna) 
	
	#write to the trimmed_stats file 
	output2.write("The length of the sequence before trimming: " + str(len(dna)) + "\n")
	output2.write("The length of the sequence after trimming: " + str(len(trimmed_dna)) + "\n")

	#this rounds the at percentage to 3 decimal places
	output2.write("The AT count of the trimmed sequence is: " + str(round(at_trimmed_dna, 3)) + "\n\n")

	
#close files
file.close()
output1.close()
output2.close()
