seq1 = open('sequences1.txt')
trim_seq = open('trimmed_seqs.txt', 'w+')
for line in seq1:
  length_of_seq = len(line)
  print(length_of_seq)
  clean = line.upper().rstrip('\n')
  my_trim = clean[13:length_of_seq]
  trim_seq.write(my_trim + "\n")
  trimmed_length = len(my_trim)
trim_stat = open('trim_stats.txt', 'w+')
for line in seq1:
    len_pre = len(line)
    print('The length of the sequence before trimming is ' + str(len.pre))
for line in trim_seq:
    len_post = len(my_trim)
    print('The length of the sequence after trimming is ' + str(len_post))
    


import sys
print('Script name is: ', sys.argv[0])
print('Number of arguments: ', len(sys.argv))
print('arguments are: ', str(sys.argv))
