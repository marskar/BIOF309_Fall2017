#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 20:38:01 2017

@author: qinliu
"""
import sys
#take a command line argument for the trimming length and print it to the screen.
print("The trimming length you want is: ", sys.argv[1])
trimmed_length = sys.argv[1] #Note the type of trimmed_length is string!!

#open the input and output files
file = open("Python/HW_1/sequences1.txt")

output_1 = open("trimmed_seqs.txt","w")
output_2 = open("trim_stats.txt","w")

for dna in file:
    
    last_character_pos = len(dna)
    #trim the sequence and make sure all letter are upper cases
    trimmed_dna = dna[int(trimmed_length):last_character_pos].upper()
    
    #write the trimmed dna and stats to output_1 and output_2, respectively
    output_1.write(trimmed_dna)
    
    AT_content = '{:.3%}'.format((trimmed_dna.count("A")+trimmed_dna.count("T"))/len(trimmed_dna))
    output_2.write("The length of the sequence before trimming is: "+\
                   str(len(dna))+"\n") 
    output_2.write("The length of the sequence after trimming is: "\
                   +str(len(trimmed_dna))+"\n")
    output_2.write("The AT content of the trimmed sequence is: "+str(AT_content)+"\n\n")
 
#close all the streaming objects
file.close()
output_1.close()
output_2.close()
    