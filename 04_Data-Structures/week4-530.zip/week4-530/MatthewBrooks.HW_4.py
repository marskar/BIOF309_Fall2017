import sys

#### Usage ####
# MatthewBrooks.HW_4.py [trim length]
###############


#Command line input for trim length
input_len = int(sys.argv[1])

#Print length to screen
print("\nTrimming " + str(input_len) + " bases from your sequences...\n")

#Open sequence file
seq_file = open("Python/HW_1/sequences1.txt")
#seq_file = open("from_the_book/input.txt") #USED FOR TESTING

#Open output files
trim_out = open("trimmed_seqs.txt", "w")
stats_out = open("trim_stats.txt", "w")


#Loop for each sequences in sequence input file
for seq in seq_file:
    #Make sequence upper case and remove EOL character
    seq_clean = seq.upper().rstrip("\n")

    #Trim the sequence
    trim_seq = seq_clean[input_len:]

    #Get original sequence length
    seq_len = len(seq_clean)
    #Get trimmed sequence length
    trim_len = len(trim_seq)

    #Calculate the AT content of the trimmed sequence
    dna_A = trim_seq.count('A')
    dna_T = trim_seq.count('T')
    perc = (dna_A + dna_T) / trim_len * 100

    #Write output of trimmed sequences
    trim_out.write(trim_seq + "\n")

    #Write output stats
    stats_out.write("Original sequence length: " + str(seq_len) + "\n")
    stats_out.write("Trimmed sequence length: " + str(trim_len) + "\n")
    stats_out.write("The trimmed AT% is: " + str(round(perc,3)) + "%\n\n")

print("Complete!\n")

#Close the files
seq_file.close()
trim_out.close()
stats_out.close()
