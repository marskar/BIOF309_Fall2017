import sys

input1 = open('Sequence1.txt')
output1 = open('trimmed_seqs.txt', 'w')
output2 = open('trim_stats.txt', 'w')
trim_length = (int(sys.argv[1]))

for seq in input1:
	seq_upper = seq.upper()
	seq_clean = seq_upper.replace('r', ' ')
	seq_trimmed = seq_clean[trim_length:]
	output1.write(seq_trimmed)
	len_untrimmed = len(seq_clean)
	len_trimmed = len(seq_trimmed)
	AT_content = ((seq_trimmed.count('A') + seq_trimmed.count('T')) / len(seq_trimmed) * 100)
	output2.write('untrimmed length: ' + str(len_untrimmed) + '; trimmed length: ' + str(len_trimmed) + '; AT content: ' + str(round(AT_content, 2)) + '%\n')
	
print('the first ' + sys.argv[1] + ' nucleotides have been trimmed for each sequence')

	
	
	
	

	
	
	

