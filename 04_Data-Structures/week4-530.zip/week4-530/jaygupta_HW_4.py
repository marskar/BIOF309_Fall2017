#Import sys first to use sys functions!
import sys
#opening and reading file with sequences
untrimmed_open = open("sequences1.txt", "r")
#opening and preparing output files for writing
trimmed_seqs = open("trimmed_seqs.txt", "w")
trimmed_stats = open("trimmed_stats.txt", "w")
#Enter desired trim length as number into command line after this file
desired_trim_length = sys.argv[1]
trim_length = int(desired_trim_length)
#for later numbering of sequences
number = 0
#make stats output file readable
trimmed_stats.write("The following displays, in order: \nLength of the untrimmed sequence, Length of the trimmed sequence, and the Percentage AT content\n")

for seq in untrimmed_open:
    #get length of untrimmed sequence
    length_of_seq = len(seq)
    #trim sequences based on number entered in command line
    ###maybe it would have been useful to have defined a variable as
    ###len(my_trim) and used that later instead of retyping len(my_trim)
    my_trim = seq[trim_length:]
    #obtain AT content as percentage - see HW2
    ACount = my_trim.count('A')
    TCount = my_trim.count('T')
    ATCount = ACount + TCount
    #number sequences
    number = number + 1
    trimmed_stats.write("Sequence #" + str(number) + "\n")
    #write trimmed sequences to trimmed_seqs.txt file
    ###this line also converts all lowercase letters to upper with the upper
    ###method
    trimmed_seqs.write("Sequence #" + str(number) + ":" + my_trim.upper())
    #write trimmed stats to trimme_stats.txt file
    trimmed_stats.write(str(length_of_seq)+", ")
    ####this line will spit out the length of the trimmed sequence
    trimmed_stats.write(str(len(my_trim))+", ")
    ###this line takes takes HW2, rounds it to 3 decimals, converts it to a
    ###string, adds a percentage sign and a new line for the next sequence
    trimmed_stats.write(str(round(ATCount / len(my_trim) * 100, 3)) + "%\n")

trimmed_stats.close()
trimmed_seqs.close()
print("You trimmed "+str(desired_trim_length)+" bases off of your sequence")
