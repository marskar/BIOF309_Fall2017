import sys # load package to allow user input arguments
#### Usage
# Bertand Lucotte_HW_4.py [trimming length]
# _ trims DNA sequences from the file sequences1.txt
# _ save trimmed sequences to trimmed_seqs.txt
# _ compute stats for raw and trimmed DNA sequences and save in trim_stats.txt


# open input files for reading
fobj = open("sequences1.txt","r")

# open new files for writing
f_trim = open("trimmed_seqs.txt","w")
f_stat = open("trim_stats.txt","w")

# length of adapter seq to remove
n = int(sys.argv[1]) # argv[0] is the script name, argv[1] is 1st input arg
print("trimming length is : %d" % n)
counter = 1

for line in fobj:
    # perform trimming and convert to upper case
    line = line.rstrip("\n")
    new_line = line[n:].upper() # goes until the end of the line, equivalent to n:-1

    # compute stats
    raw_len = len(line)
    trim_len = len(new_line)
    # compute AT content of trimmed seq
    AT_prct = (new_line.count("A") + new_line.count("T"))/len(new_line)*100

    # write trimmed seq to file
    f_trim.write(new_line + "\n")
    # write stats to file
    f_stat.write("sequence %d:\n" % counter)
    f_stat.write(" _ raw seq length: %d\n" % raw_len)
    f_stat.write(" _ trimmed seq length: %d\n" % trim_len)
    f_stat.write(" _ trimmed seq AT content: %.3g %%\n" % AT_prct)

    counter += 1

# close file objects
fobj.close()
f_trim.close()
f_stat.close()
