# open the input file
file = open("sequences1.txt")

# open the trimmed sequences output file
seqs = open("trimmed_seqs.txt", "w")

# open the stats file
stats = open("trim_stats.txt", "w")

# looping through the input file line by line, in this case each sequence
for dna in file:

    # calculate the position of the last character
    original_dna = len(dna)

    # get the substring from the 15th character to the end
    trimmed_dna = dna[14:original_dna]

    # calculate AT content of trimmed sequences
    A_count = trimmed_dna.count("A")
    T_count = trimmed_dna.count("T")
    AT_count = A_count + T_count
    percent = (AT_count/len(trimmed_dna)) * 100

    # print out the trimmed sequence by converting everything to uppercase
    seqs.write(trimmed_dna.upper())

    # print out the stats file
    stats.write(">" + "Sequence: " + dna + "\n")
    stats.write("Length before trimming: " + str(original_dna) + "\n")
    stats.write("Length after trimming: " + str(len(trimmed_dna)) + "\n")
    stats.write("AT content of trimmed DNA: " + str(percent) + "\n")

# close the seqs file
seqs.close()

# close the stats file
stats.close()
