"""
process_data.py
by Chris Coletta

The purpose of this program is to demonstrate the following principles in Python

* Read in a file
* Parse the contents using built in string operations
* Combining duplicate entries using a dict
* Using a list comprehension to iteratively create a new list with one line of code
* Creating sublists of sorted metadata
* Printing data out using format
* Writing metadata to a separate file

"""

import numpy

# STEP 1: READ IN TEXT FILE AND PARSE RAW DATA
gene_dict = {}

num_lines_in_file = 0
with open( "gene_differential_expression.txt" ) as infile:
	for line in infile:
		num_lines_in_file += 1
		gene_name, values = line.split( ' = ' )
		if gene_name not in gene_dict:
			gene_dict[ gene_name ] = values.split( ',' )
		else:
			gene_dict[ gene_name ] += values.split( ',' )

print "total number of lines in file: ", num_lines_in_file
print "total number of distinct genes: ", len( gene_dict.keys() )


# STEP 2: GENERATE METADATA (BASIC STATISTICS)
gene_stats = []

for gene_name in gene_dict:
	num_vals = len( gene_dict[ gene_name ] )
	gene_dict[ gene_name ] = numpy.array( [ float(val) for val in gene_dict[gene_name] ] )
	mean = numpy.mean( gene_dict[ gene_name ] )
	stddev = numpy.std( gene_dict[ gene_name ] )
	# Pack the stats into a list of tuples to be sorted, sliced, and diced
	gene_stats.append( ( gene_name, num_vals, mean, stddev ) )

# STEP 3: SORT THE METADATA ACCORDING TO THE FOLLOWING (ARBITRARY) CRITERIA

# Sort Criteria 1: Want genes with maximum number of measurements ("column 1")
gene_stats.sort( key = lambda A: A[1], reverse = True )
# Pair the list down to the top 15% of genes who have the most measurements
gene_stats = gene_stats[ 0: int( round( 0.15 * len( gene_stats ) ) ) ]

# Sort Criteria 2: Want genes with high precision, i.e., low standard deviation ("column 3")
gene_stats.sort( key = lambda A: A[3] )
# Pair the list down again
gene_stats = gene_stats[ 0: int( round( 0.15 * len( gene_stats ) ) ) ]

# Sort Criteria 3: Want genes with highest ABSOLUTE VALUE mean z-score


gene_stats.sort( key = lambda A: abs( A[2] ), reverse = True )

#gene_stats.sort( lambda A, B: cmp( A[3], B[3] ) if abs(A[2]) == abs(B[2]) else cmp( abs(A[2]), abs(B[2]) ), reverse = True )

# Pair the list down one more time. We only want genes with z-score > abs( 3 )
gene_stats = [ item for item in gene_stats if abs( item[2] ) > 3 ] 


# STEP 4: PRINT OUT THE FORMATTED LIST TO THE CONSOLE AND TO A FILE ALL IN ONE STEP

# open a file for writing (i.e., use additional argument 'w' to open() )
with open( "output_data.tsv", 'w' ) as outfile:

	column_headers = "{}\t{:<12}\t{}\t{}\t{}".format( "rank", "gene name", "num", "z-score", "stddev" )
	# Print column headers to console...
	print column_headers
	# ... then write them to the file as well. N.B. Need to use newline character "\n"
	outfile.write( column_headers + '\n' )

	# Now for the data itself:
	format_line = "{:>3}\t{:<12}\t{}\t{:>13.3f}\t{:.3f}"
	for gene_rank, gene_stat in enumerate( gene_stats ):
		line_item = format_line.format( gene_rank, *gene_stat )
		print line_item
		outfile.write( line_item + '\n' )



	



		

